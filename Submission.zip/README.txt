To be able to run the code, you should have SUMO traffic simulator installed in your device.

Please follow instructions here : http://sumo.dlr.de/wiki/Installing, and install the latest version of sumo
before attempting to run the program.